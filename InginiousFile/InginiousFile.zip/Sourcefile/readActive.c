#include "headers.h"
#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#define NB_ECRITURES 640
#define NB_LECTURES 2540

int mutex;
int db; // Sémaphore pour l'accès à la base de données
int priority; 

int readcount = 0; // Nombre de lecteurs actifs
int total_writes = 0;
int total_reads = 0;

void *writer(void *arg) {
    int id = *(int *)arg;
    while (1) {
        verrou_lock(&mutex);
        if (total_writes >= NB_ECRITURES) {
            verrou_unlock(&mutex);
            break; // Stop si le nombre total d'écritures est atteint
        }
        total_writes++;
        verrou_unlock(&mutex);

        semaphore_wait(&priority); // Empêche de nouveaux lecteurs d'entrer
        semaphore_wait(&db); // Accès exclusif à la base de données

        // Section critique : écriture simulée
        for (int i = 0; i < 10000; i++);
       

        semaphore_post(&db); // Libère l'accès à la base de données
        semaphore_post(&priority); // Permet aux lecteurs d'entrer à nouveau
    }
    return NULL;
}

void *reader(void *arg) {
    int id = *(int *)arg;
    while (1) {
        verrou_lock(&mutex);
        if (total_reads >= NB_LECTURES) {
            verrou_unlock(&mutex);
            break; // Stop si le nombre total de lectures est atteint
        }
        total_reads++;
        verrou_unlock(&mutex);

        semaphore_wait(&priority); 
        verrou_lock(&mutex);

        readcount++;
        if (readcount == 1) {
            semaphore_wait(&db); // Premier lecteur bloque l'accès des écrivains
        }

        verrou_unlock(&mutex);
        semaphore_post(&priority); // Permet aux écrivains d'attendre si nécessaire

        // Section critique : lecture simulée
        for (int i = 0; i < 10000; i++);
       

        verrou_lock(&mutex);

        readcount--;
        if (readcount == 0) {
            semaphore_post(&db); // Dernier lecteur libère l'accès aux écrivains
        }

        verrou_unlock(&mutex);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
     
        return EXIT_FAILURE;
    }
    mutex=0;
    db=1; // Sémaphore pour l'accès à la base de données
    priority=1;     

    int nb_writers = atoi(argv[1]);
    int nb_readers = atoi(argv[2]);

    pthread_t writers[nb_writers];
    pthread_t readers[nb_readers];

    int writer_ids[nb_writers];
    int reader_ids[nb_readers];

   


    for (int i = 0; i < nb_writers; i++) {
        writer_ids[i] = i + 1;
        pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
    }

    for (int i = 0; i < nb_readers; i++) {
        reader_ids[i] = i + 1;
        pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
    }

    for (int i = 0; i < nb_writers; i++) {
        pthread_join(writers[i], NULL);
    }

    for (int i = 0; i < nb_readers; i++) {
        pthread_join(readers[i], NULL);
    }



    return EXIT_SUCCESS;
}
